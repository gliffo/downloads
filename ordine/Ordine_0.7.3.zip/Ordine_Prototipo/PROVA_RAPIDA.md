## Scambia — aggiornamento 0.7.2

Seleziona due elementi interi di dimensioni diverse e premi Scambia. I centri si scambiano e ciascun elemento assume la lunghezza del lato maggiore dell’altro, mantenendo le proporzioni e scalando i tratti. Con forme diverse larghezza e altezza non vengono entrambe forzate sul riquadro di destinazione. Premi di nuovo: posizione e dimensioni devono tornare iniziali. Verifica Annulla in Illustrator anche con gruppo, maschera e immagine.

# Prova rapida in Illustrator

Usa una copia di un documento. Annota sistema e versione completa Illustrator. L’utente ha confermato il funzionamento della 0.1.0; la nuova Distanza esatta 0.2.0 deve ancora essere provata nell’app reale.

## Equilibra loghi 0.7.0 — prestazioni e proporzioni

1. Usa una copia con i marchi alle dimensioni di partenza, prima del vecchio calcolo. Raggruppa ogni logo completo.
2. Prova prima con tre marchi e poi con 5–10. Posiziona primo e ultimo ai limiti desiderati, lascia un intermedio fuori allineamento, seleziona tutti e premi Equilibra.
3. Default: Tra primo e ultimo, Adatta con prudenza, Orizzontale. Il calcolo usa soltanto riquadri e correzioni individuali contenute, seguite dall’adattamento comune dell’insieme. Nessun menu ottico, campo Dimensione base o Prudente B.
4. Annota il **tempo effettivo** riportato nel risultato. La prova è utile solo se risparmia tempo sullo stesso documento. Non devono partire PNG, letture delle immagini o altre finestre.
5. Controlla bordi estremi, rapporti dimensionali e peso visivo. Il riquadro non distingue stemmi/testi sottili da loghi pieni: eventuali rifiniture ottiche restano manuali. Le immagini comprendono il bianco e i margini.
6. Premi di nuovo senza modificare: deve riconoscere il risultato senza ulteriori ridimensionamenti. Sposta un estremo e ripeti: deve ricalcolare. Prova anche Mantieni dimensioni e verticale.
7. Usa Annulla e Ripristina; verifica quanti passaggi servono e che gli originali restino identici. Fermati se indica ripristino incompleto.

Il tempo e il comportamento native non sono certificati dai test cloud. [Contratto attuale](docs/EQUILIBRA_LOGHI.md). I paragrafi di versioni precedenti, se presenti sotto, sono storia del prototipo e non descrivono più il pannello 0.7.0.

## Nuovo: Distanza esatta

Crea tre rettangoli di larghezze diverse, separati e con altezze/quote Y differenti. Selezionali in ordine casuale, apri le opzioni di Distanza esatta, imposta 5 mm e Orizzontale, quindi premi il pulsante principale.

- Il più a sinistra rimane fermo; le altre Y e tutte le dimensioni restano identiche.
- Lo spazio tra i riquadri consecutivi misura 5 mm, anche con larghezze differenti.
- Prova 0 e 2,5 mm; poi Verticale: il più alto resta fermo e le X restano identiche.
- Inverti l’ordine della selezione e ripeti dopo Annulla: stesso risultato.
- Prova gruppi e una maschera; la distanza considera il riquadro di ritaglio.
- Un solo oggetto o un valore negativo devono produrre un messaggio senza spostamenti.
- Chiudi e riapri il pannello: gap e direzione restano salvati. La disposizione precedente resta invariata, con il nuovo pulsante aggiunto in fondo.
- Usa Annulla: verifica che un solo passaggio ripristini tutti gli elementi, poi prova Ripristina.

## Altre azioni e personalizzazione

1. **Scambia.** Crea due rettangoli di dimensioni differenti, distanti. Selezionali con la freccia nera e premi Scambia: devono scambiarsi il centro mantenendo dimensioni, colore, rotazione e ordine nei livelli. Un solo Annulla dovrebbe riportarli entrambi al punto iniziale; verifica anche Ripristina.
2. **Dimensioni.** Crea oggetti di 20 × 10 mm e 40 × 30 mm. Con entrambi selezionati, Stessa larghezza porta il primo a 40 × 20 mm senza spostarne il centro. Annulla. Stessa altezza porta il primo a 60 × 30 mm. Verifica il riferimento Più a sinistra, anche selezionando in ordine inverso.
3. **Riferimento preciso.** Seleziona un oggetto da solo → opzioni Larghezza → Memorizza oggetto selezionato. Seleziona altri oggetti e premi Stessa larghezza. Il riferimento può restare fuori dalla selezione. Eliminalo o cambia documento: deve comparire un messaggio, senza trasformazioni. Dopo una riapertura memorizzalo nuovamente.
4. **Sostituisci qui.** Copia un solo oggetto o un gruppo in Illustrator, seleziona due destinazioni, premi Sostituisci qui. Adatta mantiene il rapporto e il centro. Prova Riempi e ritaglia su riquadri con rapporti diversi; controlla maschera, livelli e assenza di elementi temporanei. Copia due oggetti NON raggruppati: deve rifiutare senza eliminare le destinazioni. Verifica Annulla immediatamente, controllando tutti gli oggetti e gli appunti.
5. **Sfondo.** Padding 3 mm, HEX #FFFFFF: un rettangolo dietro ogni elemento, più largo e alto di 6 mm. Lo sfondo resta separato. Prova un gruppo mascherato e un documento CMYK; controlla l’aspetto del colore e la posizione nei livelli.
6. **Tavole.** Margine 3 mm, prefisso Cliente: una tavola per oggetto/gruppo, senza spostare il disegno. Ripeti: i nomi duplicati devono ricevere un numero. La tavola precedentemente attiva deve rimanere attiva. Annulla deve lasciare intatte le tavole originali.
7. **Personalizza.** Riordina dalla maniglia e con le frecce, nascondi due azioni, premi Fine. Il trascinamento deve essere impossibile nell’uso normale. Chiudi e riapri il pannello: ordine, visibilità e opzioni devono restare. Ripristina disposizione deve conservare padding, colore e adattamento.
8. **Selezioni non valide.** Prova zero/uno/tre oggetti per Scambia, singoli punti, testo evidenziato, gruppi parziali e livelli bloccati. Nessuno sblocco o espansione automatica. Un messaggio breve deve indicare cosa selezionare.
9. **Coesistenza.** Apri Gliffo Suite e Ordine insieme: Ordine deve avere una propria voce di menu e non cambiare stato, progetti o dati della beta.

Per ogni azione verifica se basta **un solo Annulla**. Se servono più passaggi o resta un elemento temporaneo, fermati e segnala azione, selezione e risultato; non usarla ancora sul documento di produzione. Non cambiare l’orologio e non reinstallare la Suite.

## Vista compatta e tooltip

Attiva la griglia dall’intestazione: nei pulsanti devono rimanere soltanto le icone. Passa velocemente da un pulsante all’altro: nessun popup immediato. Fermati circa 750 ms su Distanza esatta: leggi funzione e ultima distanza/direzione. Escape lo chiude; puoi spostarti sopra il tooltip per leggerlo senza farlo scomparire.

Premi Opzioni nella barra sopra la griglia, poi un’icona: deve aprire un riquadro senza eseguire l’azione. Le icone non devono avere pulsanti sovrapposti negli angoli; Scambia, privo di opzioni, è disabilitato solo durante la configurazione. Cambia un valore, premi Fine o chiudi il riquadro e premi il pulsante principale: usa quel valore. Personalizza deve mostrare temporaneamente i nomi; Fine riporta alla griglia. Chiudi e riapri: stessa vista, disposizione e impostazioni. Prova anche Tab, focus, Escape e una palette stretta a 160 px; nessun comando deve diventare irraggiungibile.

Per le prove ottiche segui [PROVE_OTTICHE](docs/PROVE_OTTICHE.md). Non usare i numeri del laboratorio come correzioni certificate su documenti di produzione.

## Riprova della sessione — 0.5.1

Chiudi Illustrator e installa il pacchetto nuovo; verifica 0.5.1 sotto il logo. Su una copia seleziona tre loghi, uno per gruppo; lascia Tra primo e ultimo, scegli Mantieni dimensioni per isolare la distribuzione e premi Equilibra. Durante l’analisi non cambiare documento o selezione. Verifica risultato, Annulla e Ripristina. Ripeti con Presenza controllata. Se rifiuta, conserva il nuovo messaggio completo e la versione di Illustrator. Le prove automatiche non certificano la persistenza effettiva del motore CEP.

## WebP e altre immagini — 0.5.2

Seleziona tre immagini già collocate in Illustrator (anche il WebP che dava errore), con il primo e l’ultimo ai limiti desiderati. Prova prima Mantieni dimensioni, poi Presenza controllata. Devono comportarsi come rettangoli, senza esportazioni o controlli della qualità dei pixel. Sfondi e margini trasparenti restano dentro il riquadro. Prova anche un’immagine piccola ingrandita, una incorporata, un gruppo mascherato e un insieme misto con un logo vettoriale. Solo quest’ultimo usa il campionamento PNG. Controlla Annulla, Ripristina e che link/tipi restino invariati.

## Riprova 0.5.3 — WebP raggruppato e soli vettori

Chiudi Illustrator, installa il nuovo pacchetto e verifica 0.5.3 sotto il logo. Su una copia prova tre immagini, incluso il WebP, sia da sole sia raggruppate. Non devono passare dall’analisi PNG. Prova poi tre loghi esclusivamente vettoriali, posizionando il primo e l’ultimo ai limiti voluti e uno intermedio fuori centro. Con Mantieni dimensioni e Tra primo e ultimo controlla spostamento del logo intermedio e allineamento, poi Annulla e Ripristina. Ripeti con Presenza controllata. Se si ferma, conserva il messaggio completo, che ora include anche il tipo nativo del vettore campionato.

## Riprova 0.5.4 — applicazione

Chiudi completamente Illustrator e installa la nuova cartella, poi verifica 0.5.4. Su una copia, tre immagini: Tra primo e ultimo, Mantieni dimensioni. Il logo intermedio fuori allineamento deve spostarsi. Prova Annulla/Ripristina; poi ripeti con Presenza controllata per verificare separatamente il ridimensionamento. Ripeti con tre loghi vettoriali, incluso il GroupItem da 104,88 × 20,55 pt che esportava 513 × 103 px. Se MRAP ricompare, conserva il messaggio completo con la sottofase (lettura ingombri, ridimensionamento, posizionamento o verifica) e l’oggetto citato. Fermati se il recupero è incompleto.

## Nuovo collaudo dimensionale 0.6.0

Con tre loghi di dimensioni realistiche, verifica che non siano riportati a una misura assoluta piccola. Confronta due intervalli, uno largo il doppio dell’altro: la composizione automatica deve crescere in proporzione. Non cambiare gli aspetti dei loghi; bordi esterni ai limiti scelti, scala proporzionale, spazi sempre non negativi. Ripeti in verticale. Premi due volte senza altre modifiche: il secondo clic non deve causare un ulteriore rimpicciolimento sistematico (lievi variazioni da campionamento nativo restano da controllare). Verifica la modalità Mantieni dimensioni, il recupero delle vecchie preferenze e Annulla/Ripristina su una copia.

## Respiro 0.7.1

Sul caso con cinque marchi, conserva gli stessi estremi e usa Adatta con prudenza. Deve lasciare più vuoto fra i marchi rispetto alla 0.7.0, riducendo le dimensioni quanto serve. Verifica sinistra del primo/destra dell’ultimo, spazi uniformi, tempo reale, Annulla e Ripristina. Ripeti in verticale. Mantieni dimensioni e distanza impostata non ricevono il nuovo budget automatico.
