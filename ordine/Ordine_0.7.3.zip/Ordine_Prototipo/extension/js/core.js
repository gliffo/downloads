/* ORDINE original geometry and preference model; ES3-compatible, no host dependencies. */
(function (root, factory) {
  var api = factory();
  if (typeof module !== 'undefined' && module.exports) { module.exports = api; }
  else { root.OrdineCore = api; }
}(this, function () {
  var ids = ['swap', 'replace', 'width', 'height', 'distance', 'background', 'artboards', 'balance'];
  function number(value, min, max) {
    var text = String(value).replace(/^\s+|\s+$/g, '');
    if (!/^(?:\d+(?:[.,]\d+)?|[.,]\d+)$/.test(text)) { throw new Error('Inserisci un numero valido, con virgola o punto decimale.'); }
    var n = Number(text.replace(',', '.'));
    if (!isFinite(n) || n < min || n > max) { throw new Error('Inserisci un valore tra ' + min + ' e ' + max + '.'); }
    return n;
  }
  function box(b) {
    if (!b || b.length !== 4) { throw new Error('Ingombro non leggibile.'); }
    for (var i = 0; i < 4; i++) { if (typeof b[i] !== 'number' || !isFinite(b[i])) { throw new Error('Ingombro non valido.'); } }
    var w = b[2] - b[0], h = b[1] - b[3];
    if (w <= 0 || h <= 0) { throw new Error('Seleziona elementi con larghezza e altezza maggiori di zero.'); }
    return { left:b[0], top:b[1], right:b[2], bottom:b[3], width:w, height:h, x:(b[0]+b[2])/2, y:(b[1]+b[3])/2 };
  }
  function swap(bounds) {
    if (bounds.length !== 2) { throw new Error('Seleziona esattamente due oggetti interi.'); }
    var a=box(bounds[0]), b=box(bounds[1]);
    var scale=Math.max(b.width,b.height)/Math.max(a.width,a.height);
    if (!isFinite(scale) || scale>10000 || scale<0.0001) { throw new Error('Ridimensionamento troppo estremo.'); }
    return [{dx:b.x-a.x,dy:b.y-a.y,scale:scale},{dx:a.x-b.x,dy:a.y-b.y,scale:1/scale}];
  }
  function reference(bounds, mode, axis) {
    var best=0, a, b;
    for (var i=1;i<bounds.length;i++) {
      a=box(bounds[best]); b=box(bounds[i]);
      if ((mode==='left' && (b.left<a.left || (b.left===a.left && (b.top>a.top || (b.top===a.top && (b.width>a.width || (b.width===a.width && b.height>a.height))))))) ||
          (mode==='largest' && (b[axis]>a[axis] || (b[axis]===a[axis] && (b.left<a.left || (b.left===a.left && (b.top>a.top || (b.top===a.top && (b.width>a.width || (b.width===a.width && b.height>a.height)))))))))) { best=i; }
    }
    return best;
  }
  function fit(source, target, mode) {
    var a=box(source), b=box(target), scale=1;
    if (mode==='fit') { scale=Math.min(b.width/a.width,b.height/a.height); }
    else if (mode==='fill') { scale=Math.max(b.width/a.width,b.height/a.height); }
    else if (mode==='width') { scale=b.width/a.width; }
    else if (mode==='height') { scale=b.height/a.height; }
    else if (mode!=='original') { throw new Error('Adattamento non valido.'); }
    if (!isFinite(scale) || scale<=0 || scale>10000 || scale<0.0001) { throw new Error('Ridimensionamento troppo estremo.'); }
    return {scale:scale,x:b.x,y:b.y};
  }
  function padding(bounds, mm) {
    var b=box(bounds), p=number(mm,0,1000)*72/25.4;
    return [b.left-p,b.top+p,b.right+p,b.bottom-p];
  }
  function distance(bounds, mm, axis, keys) {
    if (!bounds || bounds.length<2) { throw new Error('Seleziona almeno due oggetti interi.'); }
    if (axis!=='horizontal' && axis!=='vertical') { throw new Error('Scegli una direzione orizzontale o verticale.'); }
    if (!keys || keys.length!==bounds.length) { throw new Error('Identificativi degli oggetti non disponibili.'); }
    var gap=number(mm,0,1000)*72/25.4, boxes=[], order=[], plans=[], seen={}, i, key;
    for(i=0;i<bounds.length;i++) {
      boxes.push(box(bounds[i]));key=keys[i];
      if(typeof key!=='string'||!key||seen['$'+key]){throw new Error('Identificativi degli oggetti non validi.');}
      seen['$'+key]=true;order.push(i);plans.push({dx:0,dy:0});
    }
    order.sort(function(a,b){
      var x=boxes[a],y=boxes[b];
      var d=axis==='horizontal' ? x.left-y.left||y.top-x.top : y.top-x.top||x.left-y.left;
      return d||(keys[a]<keys[b]?-1:keys[a]>keys[b]?1:0);
    });
    var first=boxes[order[0]],cursor=axis==='horizontal'?first.right:first.bottom;
    for(i=1;i<order.length;i++) {
      var index=order[i],current=boxes[index];
      if(axis==='horizontal') {
        var left=cursor+gap;plans[index].dx=left-current.left;cursor=left+current.width;
      } else {
        var top=cursor-gap;plans[index].dy=top-current.top;cursor=top-current.height;
      }
      if(!isFinite(cursor)||!isFinite(plans[index].dx)||!isFinite(plans[index].dy)){throw new Error('La disposizione supera i limiti di calcolo.');}
    }
    return {plans:plans,anchor:order[0],order:order,gap:gap,axis:axis};
  }
  function defaults() {
    return {version:1,view:'full',order:ids.slice(0),hidden:[],options:{replace:{fit:'fit'},width:{reference:'largest'},height:{reference:'largest'},distance:{gap:5,axis:'horizontal'},background:{padding:3,color:'#FFFFFF'},artboards:{margin:3,prefix:'Ordine'},balance:{placement:'between',gap:5,axis:'horizontal',scale:'controlled'}}};
  }
  function contains(a,v) { for(var i=0;i<a.length;i++){if(a[i]===v){return true;}}return false; }
  function sanitize(raw) {
    var d=defaults(), i,k,s,v;
    if (!raw || typeof raw!=='object') { return d; }
    if(contains(['full','compact'],raw.view)){d.view=raw.view;}
    d.order=[];
    if (raw.order instanceof Array) { for(i=0;i<raw.order.length;i++){k=raw.order[i];if(contains(ids,k)&&!contains(d.order,k)){d.order.push(k);}} }
    for(i=0;i<ids.length;i++){if(!contains(d.order,ids[i])){d.order.push(ids[i]);}}
    if(raw.hidden instanceof Array){for(i=0;i<raw.hidden.length;i++){k=raw.hidden[i];if(contains(ids,k)&&!contains(d.hidden,k)){d.hidden.push(k);}}}
    s=raw.options||{};
    for(i=0;i<ids.length;i++){
      k=ids[i];v=s[k];if(!v || typeof v!=='object'){continue;}
      if(k==='width'||k==='height'){if(contains(['largest','left','captured'],v.reference)){d.options[k].reference=v.reference;}}
      if(k==='replace'&&contains(['fit','fill','width','height','original'],v.fit)){d.options[k].fit=v.fit;}
      if(k==='balance'){
        if(contains(['between','gap'],v.placement)){d.options[k].placement=v.placement;}
        try{d.options[k].gap=number(v.gap,0,1000);}catch(_){}
        if(contains(['horizontal','vertical'],v.axis)){d.options[k].axis=v.axis;}
        if(contains(['controlled','keep'],v.scale)){d.options[k].scale=v.scale;}
      }
      if(k==='distance'){
        try{d.options[k].gap=number(v.gap,0,1000);}catch(_){}
        if(contains(['horizontal','vertical'],v.axis)){d.options[k].axis=v.axis;}
      }
      if(k==='background'){
        try{d.options[k].padding=number(v.padding,0,1000);}catch(_){}
        if(/^#[0-9a-f]{6}$/i.test(v.color||'')){d.options[k].color=v.color.toUpperCase();}
      }
      if(k==='artboards'){
        try{d.options[k].margin=number(v.margin,0,1000);}catch(_){}
        if(typeof v.prefix==='string'&&v.prefix.replace(/\s/g,'').length){d.options[k].prefix=v.prefix.replace(/[\x00-\x1f]/g,'').slice(0,60);}
      }
    }
    return d;
  }
  return {ids:ids,number:number,box:box,swap:swap,distance:distance,reference:reference,fit:fit,padding:padding,defaults:defaults,sanitize:sanitize,contains:contains};
}));
