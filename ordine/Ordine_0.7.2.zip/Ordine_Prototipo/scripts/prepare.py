#!/usr/bin/env python3
"""Sign and optionally install ORDINE only. Never modifies CEP debug settings or Suite."""
from pathlib import Path
import argparse,hashlib,json,os,platform,secrets,shutil,subprocess,sys,tempfile,urllib.request,zipfile
ROOT=Path(__file__).resolve().parents[1]
ID='it.gliffo.ordine.lab'
MAC_URL='https://raw.githubusercontent.com/Adobe-CEP/CEP-Resources/master/ZXPSignCMD/4.1.3/macOS/ZXPSignCmd'
MAC_SHA='bc773fae0b97416fc7a462e7dadcc00270428a9913480c9b78b5606ff1cfb095'

def verified_payload():
    manifest=json.loads((ROOT/'INTEGRITA.json').read_text())
    expected=manifest['files'];actual={str(p.relative_to(ROOT/'extension')) for p in (ROOT/'extension').rglob('*') if p.is_file()}
    if actual!=set(expected):raise RuntimeError('File dell’estensione diversi dal pacchetto previsto. Ricrea il pacchetto con scripts/package.py.')
    for name,digest in expected.items():
        if hashlib.sha256((ROOT/'extension'/name).read_bytes()).hexdigest()!=digest:raise RuntimeError('Integrità non valida: '+name)

def run(tool,args):
    result=subprocess.run([str(tool),*args],capture_output=True,text=True)
    if result.returncode:raise RuntimeError('Il tool Adobe non ha completato la firma/verifica. Controlla compatibilità e, su Apple Silicon, Rosetta 2. Nessuna impostazione di sicurezza è stata modificata.')
    return result.stdout

def signer(explicit):
    if explicit:
        path=Path(explicit).expanduser().resolve()
        if not path.is_file():raise RuntimeError('Percorso ZXPSignCmd non valido.')
        if sys.platform=='darwin' and hashlib.sha256(path.read_bytes()).hexdigest()!=MAC_SHA:raise RuntimeError('Il tool Mac non corrisponde al binario Adobe 4.1.3 verificato.')
        return path
    if sys.platform!='darwin':raise RuntimeError('Su Windows indica il tool ufficiale Adobe: py -3 scripts/prepare.py --signer PERCORSO/ZXPSignCmd.exe. In alternativa usa lo ZXP preparato sul Mac.')
    tools=ROOT/'.local';tools.mkdir(exist_ok=True);path=tools/'ZXPSignCmd-4.1.3'
    if not path.exists():
        print('Scarico il tool ufficiale Adobe per la firma del solo prototipo Ordine.',flush=True)
        with urllib.request.urlopen(MAC_URL,timeout=90) as response:payload=response.read(32*1024*1024)
        if hashlib.sha256(payload).hexdigest()!=MAC_SHA:raise RuntimeError('Il download del tool Adobe non corrisponde all’impronta prevista.')
        path.write_bytes(payload);path.chmod(0o700)
    if hashlib.sha256(path.read_bytes()).hexdigest()!=MAC_SHA:raise RuntimeError('Tool di firma locale modificato: rimuovi .local e riprova.')
    return path

def install(zxp):
    if sys.platform=='darwin':base=Path.home()/'Library/Application Support/Adobe/CEP/extensions'
    elif sys.platform=='win32':
        if not os.environ.get('APPDATA'):raise RuntimeError('APPDATA non disponibile.')
        base=Path(os.environ['APPDATA'])/'Adobe/CEP/extensions'
    else:raise RuntimeError('L’installazione richiede macOS o Windows.')
    base.mkdir(parents=True,exist_ok=True);target=base/ID
    if target.is_symlink():raise RuntimeError('La destinazione Ordine è un link simbolico: installazione interrotta.')
    if target.exists():
        old=target/'CSXS/manifest.xml'
        if not old.is_file() or ('ExtensionBundleId="'+ID+'"') not in old.read_text():raise RuntimeError('La cartella esistente non è identificabile come Ordine: non viene sostituita.')
    with tempfile.TemporaryDirectory(prefix='ordine-stage-',dir=base) as tmp:
        stage=Path(tmp)/'payload';stage.mkdir();backup=Path(tmp)/'previous'
        with zipfile.ZipFile(zxp) as archive:
            for info in archive.infolist():
                relative=Path(info.filename)
                if relative.is_absolute() or '..' in relative.parts or '\\' in info.filename:raise RuntimeError('Percorso non valido nello ZXP.')
            archive.extractall(stage)
        existed=target.exists()
        if existed:target.rename(backup)
        try:stage.rename(target)
        except Exception:
            if existed:backup.rename(target)
            raise
    print('Installato soltanto Ordine in: '+str(target))

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--signer');parser.add_argument('--install',action='store_true');args=parser.parse_args()
    verified_payload();tool=signer(args.signer);out=ROOT/'packages';out.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='ordine-sign-') as tmp:
        tmp=Path(tmp);cert=tmp/'prototype.p12';password=secrets.token_urlsafe(32);zxp=tmp/'Ordine_0.7.2_Prototipo.zxp'
        run(tool,['-selfSignedCert','IT','Italia','Ordine Lab','Ordine prototipo',password,str(cert),'-validityDays','365'])
        run(tool,['-sign',str(ROOT/'extension'),str(zxp),str(cert),password]);run(tool,['-verify',str(zxp)])
        destination=out/zxp.name;shutil.copyfile(zxp,destination)
        print('ZXP firmato con certificato di prototipo e verificato: '+str(destination))
        if args.install:install(destination)
    print('Apri Illustrator → Finestra → Estensioni → Ordine — prototipo.')
    print('Prima prova su una copia del documento: vedi PROVA_RAPIDA.md. Nessuna verifica nativa è stata eseguita dal build.')

if __name__=='__main__':
    try:main()
    except Exception as exc:print('Operazione interrotta: '+str(exc),file=sys.stderr);sys.exit(1)
