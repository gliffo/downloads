/* ORDINE original geometry and preference model; ES3-compatible, no host dependencies. */
(function (root, factory) {
  var api = factory();
  if (typeof module !== 'undefined' && module.exports) { module.exports = api; }
  else { root.OrdineCore = api; }
}(this, function () {
  var ids = ['swap', 'replace', 'width', 'height', 'distance', 'background', 'artboards', 'balance'];
  function number(value, min, max) {
    var text = String(value).replace(/^\s+|\s+$/g, '');
    if (!/^(?:\d+(?:[.,]\d+)?|[.,]\d+)$/.test(text)) { throw new Error('Inserisci un numero valido, con virgola o punto decimale.'); }
    var n = Number(text.replace(',', '.'));
    if (!isFinite(n) || n < min || n > max) { throw new Error('Inserisci un valore tra ' + min + ' e ' + max + '.'); }
    return n;
  }
  function box(b) {
    if (!b || b.length !== 4) { throw new Error('Ingombro non leggibile.'); }
    for (var i = 0; i < 4; i++) { if (typeof b[i] !== 'number' || !isFinite(b[i])) { throw new Error('Ingombro non valido.'); } }
    var w = b[2] - b[0], h = b[1] - b[3];
    if (w <= 0 || h <= 0) { throw new Error('Seleziona elementi con larghezza e altezza maggiori di zero.'); }
    return { left:b[0], top:b[1], right:b[2], bottom:b[3], width:w, height:h, x:(b[0]+b[2])/2, y:(b[1]+b[3])/2 };
  }
  function swap(bounds) {
    if (bounds.length !== 2) { throw new Error('Seleziona esattamente due oggetti interi.'); }
    var a=box(bounds[0]), b=box(bounds[1]);
    var scale=Math.max(b.width,b.height)/Math.max(a.width,a.height);
    if (!isFinite(scale) || scale>10000 || scale<0.0001) { throw new Error('Ridimensionamento troppo estremo.'); }
    return [{dx:b.x-a.x,dy:b.y-a.y,scale:scale},{dx:a.x-b.x,dy:a.y-b.y,scale:1/scale}];
  }
  function reference(bounds, mode, axis) {
    var best=0, a, b;
    for (var i=1;i<bounds.length;i++) {
      a=box(bounds[best]); b=box(bounds[i]);
      if ((mode==='left' && (b.left<a.left || (b.left===a.left && (b.top>a.top || (b.top===a.top && (b.width>a.width || (b.width===a.width && b.height>a.height))))))) ||
          (mode==='largest' && (b[axis]>a[axis] || (b[axis]===a[axis] && (b.left<a.left || (b.left===a.left && (b.top>a.top || (b.top===a.top && (b.width>a.width || (b.width===a.width && b.height>a.height)))))))))) { best=i; }
    }
    return best;
  }
  function fit(source, target, mode) {
    var a=box(source), b=box(target), scale=1;
    if (mode==='fit') { scale=Math.min(b.width/a.width,b.height/a.height); }
    else if (mode==='fill') { scale=Math.max(b.width/a.width,b.height/a.height); }
    else if (mode==='width') { scale=b.width/a.width; }
    else if (mode==='height') { scale=b.height/a.height; }
    else if (mode!=='original') { throw new Error('Adattamento non valido.'); }
    if (!isFinite(scale) || scale<=0 || scale>10000 || scale<0.0001) { throw new Error('Ridimensionamento troppo estremo.'); }
    return {scale:scale,x:b.x,y:b.y};
  }
  function padding(bounds, mm) {
    var b=box(bounds), p=number(mm,0,1000)*72/25.4;
    return [b.left-p,b.top+p,b.right+p,b.bottom-p];
  }
  function distance(bounds, mm, axis, keys) {
    if (!bounds || bounds.length<2) { throw new Error('Seleziona almeno due oggetti interi.'); }
    if (axis!=='horizontal' && axis!=='vertical') { throw new Error('Scegli una direzione orizzontale o verticale.'); }
    if (!keys || keys.length!==bounds.length) { throw new Error('Identificativi degli oggetti non disponibili.'); }
    var gap=number(mm,0,1000)*72/25.4, boxes=[], order=[], plans=[], seen={}, i, key;
    for(i=0;i<bounds.length;i++) {
      boxes.push(box(bounds[i]));key=keys[i];
      if(typeof key!=='string'||!key||seen['$'+key]){throw new Error('Identificativi degli oggetti non validi.');}
      seen['$'+key]=true;order.push(i);plans.push({dx:0,dy:0});
    }
    order.sort(function(a,b){
      var x=boxes[a],y=boxes[b];
      var d=axis==='horizontal' ? x.left-y.left||y.top-x.top : y.top-x.top||x.left-y.left;
      return d||(keys[a]<keys[b]?-1:keys[a]>keys[b]?1:0);
    });
    var first=boxes[order[0]],cursor=axis==='horizontal'?first.right:first.bottom;
    for(i=1;i<order.length;i++) {
      var index=order[i],current=boxes[index];
      if(axis==='horizontal') {
        var left=cursor+gap;plans[index].dx=left-current.left;cursor=left+current.width;
      } else {
        var top=cursor-gap;plans[index].dy=top-current.top;cursor=top-current.height;
      }
      if(!isFinite(cursor)||!isFinite(plans[index].dx)||!isFinite(plans[index].dy)){throw new Error('La disposizione supera i limiti di calcolo.');}
    }
    return {plans:plans,anchor:order[0],order:order,gap:gap,axis:axis};
  }
  function defaults() {
    return {version:1,view:'full',order:ids.slice(0),hidden:[],options:{replace:{fit:'fit'},width:{reference:'largest'},height:{reference:'largest'},distance:{gap:5,axis:'horizontal'},background:{padding:3,color:'#FFFFFF'},artboards:{margin:3,prefix:'Ordine'},balance:{placement:'between',gap:5,axis:'horizontal',scale:'controlled'}}};
  }
  function contains(a,v) { for(var i=0;i<a.length;i++){if(a[i]===v){return true;}}return false; }
  function sanitize(raw) {
    var d=defaults(), i,k,s,v;
    if (!raw || typeof raw!=='object') { return d; }
    if(contains(['full','compact'],raw.view)){d.view=raw.view;}
    d.order=[];
    if (raw.order instanceof Array) { for(i=0;i<raw.order.length;i++){k=raw.order[i];if(contains(ids,k)&&!contains(d.order,k)){d.order.push(k);}} }
    for(i=0;i<ids.length;i++){if(!contains(d.order,ids[i])){d.order.push(ids[i]);}}
    if(raw.hidden instanceof Array){for(i=0;i<raw.hidden.length;i++){k=raw.hidden[i];if(contains(ids,k)&&!contains(d.hidden,k)){d.hidden.push(k);}}}
    s=raw.options||{};
    for(i=0;i<ids.length;i++){
      k=ids[i];v=s[k];if(!v || typeof v!=='object'){continue;}
      if(k==='width'||k==='height'){if(contains(['largest','left','captured'],v.reference)){d.options[k].reference=v.reference;}}
      if(k==='replace'&&contains(['fit','fill','width','height','original'],v.fit)){d.options[k].fit=v.fit;}
      if(k==='balance'){
        if(contains(['between','gap'],v.placement)){d.options[k].placement=v.placement;}
        try{d.options[k].gap=number(v.gap,0,1000);}catch(_){}
        if(contains(['horizontal','vertical'],v.axis)){d.options[k].axis=v.axis;}
        if(contains(['controlled','keep'],v.scale)){d.options[k].scale=v.scale;}
      }
      if(k==='distance'){
        try{d.options[k].gap=number(v.gap,0,1000);}catch(_){}
        if(contains(['horizontal','vertical'],v.axis)){d.options[k].axis=v.axis;}
      }
      if(k==='background'){
        try{d.options[k].padding=number(v.padding,0,1000);}catch(_){}
        if(/^#[0-9a-f]{6}$/i.test(v.color||'')){d.options[k].color=v.color.toUpperCase();}
      }
      if(k==='artboards'){
        try{d.options[k].margin=number(v.margin,0,1000);}catch(_){}
        if(typeof v.prefix==='string'&&v.prefix.replace(/\s/g,'').length){d.options[k].prefix=v.prefix.replace(/[\x00-\x1f]/g,'').slice(0,60);}
      }
    }
    return d;
  }
  return {ids:ids,number:number,box:box,swap:swap,distance:distance,reference:reference,fit:fit,padding:padding,defaults:defaults,sanitize:sanitize,contains:contains};
}));

/* ES3 rectangle planner shared with the native host. No raster, profiles or I/O. */
(function(root,factory){if(typeof module!=='undefined'&&module.exports){module.exports=factory(require('./core.js'));}else{root.OrdineFastBalance=factory(root.OrdineCore);}}(this,function(C){
 function median(values){var a=values.slice(0);a.sort(function(x,y){return x-y;});var m=Math.floor(a.length/2);return a.length%2?a[m]:(a[m-1]+a[m])/2;}
 function build(bounds,cfg,keys){
  if(!bounds||bounds.length<2||bounds.length>24){throw new Error('Seleziona da 2 a 24 oggetti interi.');}
  if(!C.contains(['horizontal','vertical'],cfg.axis)||!C.contains(['between','gap'],cfg.placement)||!C.contains(['controlled','keep'],cfg.scale)){throw new Error('Impostazioni di distribuzione non valide.');}
  if(!keys||keys.length!==bounds.length){throw new Error('Identificativi della selezione non validi.');}
  var a=[],seen={},areas=[],i,b,key;
  for(i=0;i<bounds.length;i++){b=C.box(bounds[i]);key=keys[i];if(typeof key!=='string'||!key||seen['$'+key]){throw new Error('Identificativi della selezione non validi.');}seen['$'+key]=true;a.push({b:b,index:i,id:key});areas.push(Math.sqrt(b.width*b.height));}
  var horizontal=cfg.axis==='horizontal',reference=median(areas),occupied=0,cross=[];
  a.sort(function(x,y){return (horizontal?x.b.left-y.b.left||y.b.top-x.b.top:y.b.top-x.b.top||x.b.left-y.b.left)||(x.id<y.id?-1:1);});
  var first=a[0],last=a[a.length-1],start=horizontal?first.b.left:first.b.top,end=horizontal?last.b.right:last.b.bottom,span=horizontal?end-start:start-end,axis=horizontal?first.b.y:first.b.x;
  for(i=0;i<a.length;i++){var e=a[i];e.scale=cfg.scale==='controlled'?Math.max(.85,Math.min(1.15,reference/Math.sqrt(e.b.width*e.b.height))):1;e.w=e.b.width*e.scale;e.h=e.b.height*e.scale;occupied+=horizontal?e.w:e.h;cross.push(horizontal?e.h:e.w);}
  // Reserve at least 25% of the interval for internal gaps, and at least
  // one median cross-size per gap after the common scale. No extra host work.
  if(cfg.scale==='controlled'&&cfg.placement==='between'){var fit=Math.min(span*.75/occupied,span/(occupied+(a.length-1)*median(cross)));occupied=0;for(i=0;i<a.length;i++){a[i].scale*=fit;a[i].w*=fit;a[i].h*=fit;occupied+=horizontal?a[i].w:a[i].h;}}
  if(cfg.placement==='between'&&occupied-span>.000001){throw new Error('I loghi non entrano: allontana gli estremi oppure scegli Adatta allo spazio.');}
  var gap=cfg.placement==='between'?Math.max(0,span-occupied)/(a.length-1):C.number(cfg.gap,0,1000)*72/25.4,cursor=start,plans=[],layout=[];
  for(i=0;i<a.length;i++){e=a[i];if(!isFinite(e.scale)||e.scale<.01||e.scale>100){throw new Error('Ridimensionamento troppo estremo: cambia la posizione degli estremi.');}
   var position=cfg.placement==='between'&&i===a.length-1?(horizontal?end-e.w:end+e.h):cursor,left=horizontal?position:axis-e.w/2,top=horizontal?axis+e.h/2:position,frame=[left,top,left+e.w,top-e.h];
   if(!isFinite(left)||!isFinite(top)||left<-16300||top>16300||frame[2]>16300||frame[3]<-16300||e.w>16300||e.h>16300){throw new Error('La composizione supera i limiti del canvas. Avvicina gli estremi.');}
   plans[e.index]={id:e.id,scale:e.scale,dx:left+e.w/2-e.b.x,dy:top-e.h/2-e.b.y};layout.push({id:e.id,left:left,top:top,width:e.w,height:e.h});cursor=horizontal?left+e.w+gap:top-e.h-gap;
  }
  return {plans:plans,layout:layout,gap:gap};
 }
 return {build:build};
}));

/* Small non-evaluating JSON codec for the ExtendScript bridge. */
var OrdineCodec = (function () {
  function stringify(v) {
    var a=[],i,t=typeof v;
    if(v===null||t==='undefined'){return 'null';}
    if(t==='number'){return isFinite(v)?String(v):'null';}
    if(t==='boolean'){return String(v);}
    if(t==='string'){return '"'+v.replace(/[\\"\x00-\x1f\u2028\u2029]/g,function(c){var m={'"':'\\"','\\':'\\\\','\n':'\\n','\r':'\\r','\t':'\\t'};return m[c]||'\\u'+('0000'+c.charCodeAt(0).toString(16)).slice(-4);})+'"';}
    if(v instanceof Array){for(i=0;i<v.length;i++){a.push(stringify(v[i]));}return '['+a.join(',')+']';}
    for(i in v){if(v.hasOwnProperty(i)){a.push(stringify(i)+':'+stringify(v[i]));}}return '{'+a.join(',')+'}';
  }
  function parse(text) {
    var n=0,depth=0;
    function fail(){throw new Error('Richiesta del pannello non valida.');}
    function white(){while(/\s/.test(text.charAt(n))&&n<text.length){n++;}}
    function str(){var out='',c,e,h;n++;while(n<text.length){c=text.charAt(n++);if(c==='"'){return out;}if(c==='\\'){e=text.charAt(n++);if(e==='u'){h=text.substr(n,4);if(!/^[0-9a-f]{4}$/i.test(h)){fail();}out+=String.fromCharCode(parseInt(h,16));n+=4;}else{var m={'"':'"','\\':'\\','/':'/','b':'\b','f':'\f','n':'\n','r':'\r','t':'\t'};if(!m.hasOwnProperty(e)){fail();}out+=m[e];}}else{if(c.charCodeAt(0)<32){fail();}out+=c;}}fail();}
    function value(){white();if(++depth>15){fail();}var c=text.charAt(n),v,k,m;
      if(c==='"'){v=str();}
      else if(c==='{'||c==='['){var object=c==='{';v=object?{}:[];n++;white();if(text.charAt(n)===(object?'}':']')){n++;}else{while(true){if(object){white();if(text.charAt(n)!=='"'){fail();}k=str();if(k==='__proto__'||k==='constructor'||k==='prototype'){fail();}white();if(text.charAt(n++)!==':'){fail();}v[k]=value();}else{v.push(value());}white();c=text.charAt(n++);if(c===(object?'}':']')){break;}if(c!==','){fail();}}}}
      else{m=/^(true|false|null|-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?)/.exec(text.substr(n));if(!m){fail();}n+=m[0].length;v=m[0]==='true'?true:m[0]==='false'?false:m[0]==='null'?null:Number(m[0]);if(typeof v==='number'&&!isFinite(v)){fail();}}
      depth--;return v;
    }
    if(typeof text!=='string'||text.length>32768){fail();}var result=value();white();if(n!==text.length){fail();}return result;
  }
  return {parse:parse,stringify:stringify};
}());

/* ORDINE independent host. Each action reads the current selection synchronously. */
var OrdineLab;
// CEP may load ScriptPath again: keep same-build host state across evaluations.
if (!OrdineLab || OrdineLab.version!=='0.7.2') {
OrdineLab = (function (C) {
  var O={actions:{},reference:null,version:'0.7.2'};
  function error(message){throw new Error(message);}
  O.document=function(){if(!app.documents.length){error('Apri un documento Illustrator e seleziona gli oggetti.');}var d=app.activeDocument;if(d.scaleFactor&&d.scaleFactor!==1){error('Il prototipo non supporta documenti in formato grande.');}return d;};
  O.array=function(collection){var a=[];for(var i=0;i<collection.length;i++){a.push(collection[i]);}return a;};
  O.parents=function(item,doc){for(var p=item,guard=0;p&&p!==doc&&guard<100;p=p.parent,guard++){if(p.locked||p.hidden||p.visible===false){error('Seleziona elementi visibili e sbloccati, anche nei livelli.');}if(p.isIsolated){error('Esci dalla modalità isolamento prima di usare Ordine.');}}if(p!==doc){error('Elemento non appartenente al documento attivo.');}};
  O.inspect=function(item,doc,depth,fast){
    if(depth>30){error('Gruppo troppo annidato per il prototipo.');}O.parents(item,doc);
    if(depth===0){for(var ancestor=item.parent;ancestor&&ancestor!==doc;ancestor=ancestor.parent){if(ancestor.clipped){error('Seleziona il gruppo mascherato intero, non un elemento al suo interno.');}}}
    var t=item.typename,i,child,selected=0,total=0;
    if(!C.contains(['PathItem','CompoundPathItem','GroupItem','TextFrame','PlacedItem','RasterItem'],t)){error('Seleziona tracciati, testi puntuali, immagini o gruppi; questo tipo non è supportato.');}
    if(item.guides){error('Le guide non sono supportate.');}
    if(t==='TextFrame'){
      if(item.kind!==TextType.POINTTEXT||item.nextFrame||item.previousFrame){error('Usa testo puntuale non concatenato; testo in area e su tracciato esclusi.');}
    }
    if(t==='PathItem'){
      total=item.pathPoints.length;
      var aggregate=null;if(fast){try{var selectedPoints=item.selectedPathPoints;if(selectedPoints&&typeof selectedPoints.length==='number'){aggregate=selectedPoints.length;}}catch(_){}}
      if(aggregate!==null&&aggregate>=0&&aggregate<=total&&aggregate===Math.floor(aggregate)){selected=aggregate;}else{for(i=0;i<total;i++){if(item.pathPoints[i].selected!==PathPointSelection.NOSELECTION){selected++;}}}
      if(selected>0&&selected<total){error('Seleziona gli oggetti interi con la freccia nera, non singoli punti.');}
    }
    if(t==='GroupItem'){
      total=0;selected=0;
      for(i=0;i<item.pageItems.length;i++){child=item.pageItems[i];if(child.parent!==item){continue;}total++;if(child.selected){selected++;}O.inspect(child,doc,depth+1,fast);}
      if(selected>0&&selected<total){error('Seleziona il gruppo intero con la freccia nera.');}
    }
    if(t==='CompoundPathItem'){for(i=0;i<item.pathItems.length;i++){O.inspect(item.pathItems[i],doc,depth+1,fast);}}
  };
  O.bounds=function(item){
    if(item.typename==='GroupItem'&&item.clipped){
      var clips=[];for(var i=0;i<item.pageItems.length;i++){
        var p=item.pageItems[i];if(p.parent!==item){continue;}
        if(p.clipping||(p.typename==='CompoundPathItem'&&p.pathItems.length&&p.pathItems[0].clipping)){clips.push(p);}
      }
      if(clips.length!==1){error('Maschera non leggibile: usa un gruppo con una sola maschera di ritaglio.');}
      var clip=O.array(clips[0].geometricBounds);C.box(clip);return clip;
    }
    var b=O.array(item.visibleBounds);C.box(b);return b;
  };
  O.selection=function(doc,min,max,fast){
    var raw=doc.selection;if(!raw||raw.typename==='TextRange'||typeof raw.length!=='number'){error('Seleziona gli oggetti interi con la freccia nera.');}
    var a=O.array(raw),i,j,p;
    if(a.length<min||(max&&a.length>max)){error(max===1?'Seleziona un solo oggetto intero.':max===2?'Seleziona esattamente due oggetti interi.':'Seleziona almeno '+min+' oggett'+(min===1?'o intero.':'i interi.'));}
    for(i=0;i<a.length;i++){
      O.inspect(a[i],doc,0,fast);if(!fast){O.bounds(a[i]);}
      for(j=0;j<i;j++){
        if(a[i]===a[j]){error('Selezione duplicata: seleziona di nuovo gli oggetti.');}
        for(p=a[i].parent;p&&p!==doc;p=p.parent){if(p===a[j]){error('Seleziona solo il gruppo o solo i suoi elementi.');}}
        for(p=a[j].parent;p&&p!==doc;p=p.parent){if(p===a[i]){error('Seleziona solo il gruppo o solo i suoi elementi.');}}
      }
    }
    return a;
  };
  O.snapshot=function(items){var a=[];for(var i=0;i<items.length;i++){a.push({item:items[i],bounds:O.bounds(items[i])});}return a;};
  O.resize=function(item,factor){if(Math.abs(factor-1)<0.00000001){return;}item.resize(factor*100,factor*100,true,true,true,true,factor*100,Transformation.CENTER);};
  O.center=function(item,x,y){var b=C.box(O.bounds(item)),dx=x-b.x,dy=y-b.y;if(Math.abs(dx)>0.00001||Math.abs(dy)>0.00001){item.translate(dx,dy,true,true,true,true);}};
  O.near=function(a,b){for(var i=0;i<4;i++){if(Math.abs(a[i]-b[i])>0.02){return false;}}return true;};
  O.restore=function(snap){var failures=[];for(var i=snap.length-1;i>=0;i--){try{var s=snap[i],old=C.box(s.bounds),now=C.box(O.bounds(s.item));if(!O.near(s.bounds,O.bounds(s.item))){O.resize(s.item,old.width/now.width);O.center(s.item,old.x,old.y);}if(!O.near(O.bounds(s.item),s.bounds)){failures.push(i);}}catch(_){failures.push(i);}}return failures.length===0;};
  O.transform=function(items,plans,trace,knownBounds){
    function step(text){if(trace){trace(text);}}
    step('lettura ingombri iniziali');var snap=[];if(knownBounds){if(knownBounds.length!==items.length){error('Ingombri iniziali non validi.');}for(var s=0;s<items.length;s++){C.box(knownBounds[s]);snap.push({item:items[s],bounds:knownBounds[s].slice(0)});}}else{snap=O.snapshot(items);}
    try{
      for(var i=0;i<items.length;i++){
        var old=C.box(snap[i].bounds),p=plans[i];if(trace){step('ridimensionamento '+O.label(items[i],i));}O.resize(items[i],p.scale||1);if(trace){step('posizionamento '+O.label(items[i],i));}O.center(items[i],old.x+(p.dx||0),old.y+(p.dy||0));
        if(trace){step('verifica risultato '+O.label(items[i],i));}var n=C.box(O.bounds(items[i]));if(Math.abs(n.width-old.width*(p.scale||1))>0.02||Math.abs(n.height-old.height*(p.scale||1))>0.02||Math.abs(n.x-old.x-(p.dx||0))>0.02||Math.abs(n.y-old.y-(p.dy||0))>0.02){error('Aspetto non misurabile con precisione: operazione interrotta.');}
      }
    }catch(e){var restored=O.restore(snap);error(String(e.message||e)+(restored?' Geometria ripristinata.':' Ripristino incompleto: usa subito Annulla e controlla il documento.'));}
  };
  O.inventory=function(doc){var map={};for(var i=0;i<doc.pageItems.length;i++){var id=doc.pageItems[i].uuid;if(!id){error('Identificativi degli oggetti non disponibili.');}map['$'+id]=true;}return map;};
  O.newRoots=function(doc,before){var roots=[],i,item,p,nested;for(i=0;i<doc.pageItems.length;i++){item=doc.pageItems[i];if(before['$'+item.uuid]){continue;}nested=false;for(p=item.parent;p&&p!==doc;p=p.parent){if(p.uuid&&!before['$'+p.uuid]){nested=true;break;}}if(!nested){roots.push(item);}}return roots;};
  O.spatial=function(items){var a=items.slice(0);a.sort(function(x,y){var b=O.bounds(x),c=O.bounds(y);return c[1]-b[1]||b[0]-c[0]||(x.uuid<y.uuid?-1:x.uuid>y.uuid?1:0);});return a;};
  O.remove=function(items){var ok=true;for(var i=items.length-1;i>=0;i--){try{items[i].remove();}catch(_){ok=false;}}return ok;};
  O.restoreSelection=function(doc,items){try{doc.selection=null;for(var i=0;i<items.length;i++){try{items[i].selected=true;}catch(_){}}}catch(_){} };
  O.rect=function(b){C.box(b);if(b[0]<-16300||b[1]>16300||b[2]>16300||b[3]<-16300||b[2]-b[0]>16300||b[1]-b[3]>16300){error('Ingombro oltre i limiti conservativi del prototipo (16300 pt).');}return b;};
  O.label=function(item,index){var n='';try{n=item.name;}catch(_){}return (n||'Elemento '+(index+1)).replace(/[\x00-\x1f]/g,' ').substr(0,100);};
  O.referenceItem=function(doc,items,mode,axis){
    if(mode==='captured'){
      var r=O.reference;if(!r||r.doc!==doc){error('Apri le opzioni e memorizza un riferimento in questo documento.');}
      try{var found=doc.getPageItemFromUuid(r.uuid);if(!found||found.uuid!==r.uuid){error('Riferimento non più valido.');}r.item=found;O.inspect(r.item,doc,0);O.bounds(r.item);}catch(_){error('Riferimento non più disponibile: memorizzalo di nuovo.');}return r.item;
    }
    var bounds=[];for(var i=0;i<items.length;i++){bounds.push(O.bounds(items[i]));}return items[C.reference(bounds,mode,axis)];
  };
  O.capture=function(){var doc=O.document(),items=O.selection(doc,1,1),it=items[0];O.reference={doc:doc,item:it,uuid:it.uuid};return {message:'Riferimento: '+O.label(it,0)+'. Valido finché il documento resta aperto.'};};
  O.dispatch=function(encoded){
    try{
      var request=OrdineCodec.parse(decodeURIComponent(encoded));
      if(!request||typeof request!=='object'){error('Richiesta non valida.');}
      if(request.action==='ping'){return OrdineCodec.stringify({ok:true,version:O.version});}
      if(request.action==='capture'){var c=O.capture();c.ok=true;return OrdineCodec.stringify(c);}
      if(request.action==='balanceQuick'){var quickPref={options:{balance:request.options||{}}},quick=O.balanceQuick(O.document(),C.sanitize(quickPref).options.balance);quick.ok=true;quick.version=O.version;return OrdineCodec.stringify(quick);}
      if(C.contains(['balanceCapture','balanceApply','balanceCancel'],request.action)){
        if(typeof O.balanceCapture!=='function'){error('L’analisi ottica non è disponibile nel pannello rapido. Aggiorna Ordine e riaprilo.');}
        var special;
        // Explicit, mutually exclusive stages: capture must never invoke apply/cancel.
        if(request.action==='balanceCapture'){special=O.balanceCapture(O.document());}
        else if(request.action==='balanceApply'){special=O.balanceApply(O.document(),request.options);}
        else{special=O.balanceCancel(request.options);}
        special.ok=true;special.version=O.version;return OrdineCodec.stringify(special);
      }
      if(!O.actions.hasOwnProperty(request.action)){error('Azione non disponibile.');}
      if(request.action==='distance'){var raw=request.options||{};if(raw.gap!==undefined){C.number(raw.gap,0,1000);}if(raw.axis!==undefined&&!C.contains(['horizontal','vertical'],raw.axis)){error('Scegli una direzione orizzontale o verticale.');}}
      var pref={options:{}};pref.options[request.action]=request.options||{};var options=C.sanitize(pref).options[request.action]||{};
      var result=O.actions[request.action](O.document(),options)||{};result.ok=true;return OrdineCodec.stringify(result);
    }catch(e){return OrdineCodec.stringify({ok:false,message:String(e.message||e),operation:e.operation||((request&&request.action)||''),version:O.version});}
  };
  return O;
}(OrdineCore));

}

(function(O,C){O.actions.artboards=function(doc,cfg){
  var items=O.spatial(O.selection(doc,1)),jobs=[],used={},i,name,base,suffix;
  if(doc.artboards.length+items.length>1000){throw new Error('La selezione supera il limite di 1000 tavole.');}
  for(i=0;i<doc.artboards.length;i++){used['$'+doc.artboards[i].name]=true;}
  for(i=0;i<items.length;i++){
    base=cfg.prefix+' — '+O.label(items[i],i);name=base;suffix=2;while(used['$'+name]){name=base+' ('+suffix+++')';}used['$'+name]=true;
    jobs.push({bounds:O.rect(C.padding(O.bounds(items[i]),cfg.margin)),name:name});
  }
  var initialCount=doc.artboards.length,made=[],active=doc.artboards.getActiveArtboardIndex();
  try{for(i=0;i<jobs.length;i++){var board=doc.artboards.add(jobs[i].bounds);made.push(board);board.name=jobs[i].name;}}
  catch(e){var additions=[];for(var j=initialCount;j<doc.artboards.length;j++){additions.push(doc.artboards[j]);}var ok=O.remove(additions);throw new Error(String(e.message||e)+(ok?' Tavole parziali rimosse.':' Usa subito Annulla: rimozione parziale non riuscita.'));}
  finally{try{doc.artboards.setActiveArtboardIndex(active);}catch(_){}O.restoreSelection(doc,items);}
  return {message:made.length+' tavol'+(made.length===1?'a creata.':'e create.')};
};}(OrdineLab,OrdineCore));

(function(O,C){O.actions.background=function(doc,cfg){
  var items=O.selection(doc,1),boxes=[],made=[],i;
  for(i=0;i<items.length;i++){boxes.push(O.rect(C.padding(O.bounds(items[i]),cfg.padding)));}
  var oldLayer=doc.activeLayer,before=O.inventory(doc);
  try{
    for(i=0;i<items.length;i++){
      var b=boxes[i],parent=items[i].parent,rect=parent.pathItems.rectangle(b[1],b[0],b[2]-b[0],b[1]-b[3]);made.push(rect);
      rect.name=O.label(items[i],i)+' — sfondo';rect.stroked=false;rect.filled=true;
      var rgb=new RGBColor();rgb.red=parseInt(cfg.color.substr(1,2),16);rgb.green=parseInt(cfg.color.substr(3,2),16);rgb.blue=parseInt(cfg.color.substr(5,2),16);rect.fillColor=rgb;
      rect.move(items[i],ElementPlacement.PLACEAFTER);
    }
  }catch(e){var ok=O.remove(O.newRoots(doc,before));throw new Error(String(e.message||e)+(ok?' Sfondi parziali rimossi.':' Usa subito Annulla: rimozione parziale non riuscita.'));}
  finally{try{doc.activeLayer=oldLayer;}catch(_){}O.restoreSelection(doc,items);}
  return {message:made.length+' sfond'+(made.length===1?'o creato.':'i creati.')};
};}(OrdineLab,OrdineCore));

/* Single synchronous host call: current selection, rectangle math, transform. */
(function(O,C,F){
 O.balanceQuick=function(doc,options){
  var start=new Date().getTime(),stage='lettura selezione',n;
  try{
   if(doc.selection&&doc.selection.length>24){throw new Error('Seleziona al massimo 24 oggetti interi.');}
   var items=O.selection(doc,2,24,true),selectedAt=new Date().getTime(),bounds=[],ids=[];
   for(var i=0;i<items.length;i++){bounds.push(O.bounds(items[i]));ids.push(String(items[i].uuid||''));}
   var key=options.axis+'|'+options.placement+'|'+options.scale+'|'+(options.placement==='gap'?options.gap:''),last=O.quickBalanceLast,unchanged=!!(last&&last.key===key&&last.count===items.length);
   if(unchanged){for(i=0;i<items.length;i++){if(!last.frames['$'+ids[i]]||!O.near(bounds[i],last.frames['$'+ids[i]])){unchanged=false;break;}}}
   if(unchanged){return {operation:'balanceQuick',message:'I loghi sono già nella disposizione calcolata.',timings:{selectionMs:selectedAt-start,planMs:0,applyMs:0,totalMs:new Date().getTime()-start}};}
   O.quickBalanceLast=null;stage='calcolo riquadri';var proposal=F.build(bounds,options,ids),plannedAt=new Date().getTime();
   // Planner preflights every target before the first original is touched.
   stage='applicazione';O.transform(items,proposal.plans,function(detail){stage=detail;},bounds);
   var frames={};for(i=0;i<proposal.layout.length;i++){var itemLayout=proposal.layout[i];frames['$'+itemLayout.id]=[itemLayout.left,itemLayout.top,itemLayout.left+itemLayout.width,itemLayout.top-itemLayout.height];}O.quickBalanceLast={key:key,count:items.length,frames:frames};
   var ended=new Date().getTime();return {operation:'balanceQuick',message:items.length+' loghi equilibrati.',timings:{selectionMs:selectedAt-start,planMs:plannedAt-selectedAt,applyMs:ended-plannedAt,totalMs:ended-start}};
  }catch(e){O.quickBalanceLast=null;var failure=new Error('['+stage+'] '+String(e.message||e));failure.operation='balanceQuick';throw failure;}
 };
}(OrdineLab,OrdineCore,OrdineFastBalance));

/* Equal edge-to-edge gaps. Spatial order is independent of selection order. */
(function(O,C){O.actions.distance=function(doc,cfg){
  var items=O.selection(doc,2),bounds=[],keys=[],i;
  for(i=0;i<items.length;i++){bounds.push(O.bounds(items[i]));keys.push(String(items[i].uuid||''));}
  var layout=C.distance(bounds,cfg.gap,cfg.axis,keys);
  /* Validate the entire destination layout before moving any selected artwork. */
  for(i=0;i<items.length;i++){
    var b=bounds[i],p=layout.plans[i];O.rect([b[0]+p.dx,b[1]+p.dy,b[2]+p.dx,b[3]+p.dy]);
  }
  O.transform(items,layout.plans);
  return {message:'Distanza '+String(cfg.gap).replace('.',',')+' mm applicata in '+(cfg.axis==='horizontal'?'orizzontale':'verticale')+'. Fermo: '+O.label(items[layout.anchor],layout.anchor)+'.'};
};}(OrdineLab,OrdineCore));

(function(O,C){O.actions.height=function(doc,cfg){var items=O.selection(doc,cfg.reference==='captured'?1:2),reference=O.referenceItem(doc,items,cfg.reference,'height'),target=C.box(O.bounds(reference)).height,plans=[];for(var i=0;i<items.length;i++){var factor=target/C.box(O.bounds(items[i])).height;if(factor<0.0001||factor>10000){throw new Error('Ridimensionamento troppo estremo.');}plans.push({scale:factor});}O.transform(items,plans);return {message:'Altezza uniformata. Riferimento: '+O.label(reference,0)+'.'};};}(OrdineLab,OrdineCore));

(function(O,C){
  function live(doc,item){try{return !!doc.getPageItemFromUuid(item.uuid);}catch(_){return false;}}
  O.actions.replace=function(doc,cfg){
    var targets=O.selection(doc,1),jobs=O.snapshot(targets),before=O.inventory(doc),pasted=[],made=[],backups=[],i,oldLayer=doc.activeLayer,committed=false;
    O.parents(oldLayer,doc);
    try{
      doc.selection=null;var pasteError=null;try{app.paste();}catch(e){pasteError=e;}pasted=O.newRoots(doc,before);
      if(pasteError){throw new Error('Appunti non importabili: copia un oggetto da Illustrator.');}
      if(pasted.length!==1){throw new Error('Copia un solo oggetto o un gruppo in Illustrator, poi seleziona le destinazioni.');}
      var source=pasted[0];O.inspect(source,doc,0);var sourceBounds=O.bounds(source);
      for(i=0;i<jobs.length;i++){jobs[i].fit=C.fit(sourceBounds,jobs[i].bounds,cfg.fit);O.rect(jobs[i].bounds);}
      for(i=0;i<jobs.length;i++){
        var target=jobs[i].item,b=jobs[i].bounds,fit=jobs[i].fit,copy,group=null;
        if(cfg.fit==='fill'){group=target.parent.groupItems.add();made.push(group);group.move(target,ElementPlacement.PLACEBEFORE);copy=source.duplicate(group,ElementPlacement.PLACEATBEGINNING);}
        else{copy=source.duplicate(target,ElementPlacement.PLACEBEFORE);made.push(copy);}
        O.resize(copy,fit.scale);O.center(copy,fit.x,fit.y);
        var fitted=C.box(O.bounds(copy)),src=C.box(sourceBounds);
        if(Math.abs(fitted.width-src.width*fit.scale)>0.02||Math.abs(fitted.height-src.height*fit.scale)>0.02){throw new Error('Elemento copiato non ridimensionabile con precisione.');}
        if(group){var mask=group.pathItems.rectangle(b[1],b[0],b[2]-b[0],b[1]-b[3]);mask.stroked=false;mask.filled=false;mask.clipping=true;mask.zOrder(ZOrderMethod.BRINGTOFRONT);group.clipped=true;}
        made[made.length-1].name=target.name||'Sostituzione';
      }
      for(i=0;i<targets.length;i++){var backup=targets[i].duplicate(targets[i],ElementPlacement.PLACEAFTER);backups.push(backup);backup.hidden=true;}
      if(!O.remove(pasted)){throw new Error('Impossibile eliminare l’elemento temporaneo incollato.');}pasted=[];
      for(i=0;i<targets.length;i++){targets[i].remove();}committed=true;
      var cleaned=O.remove(backups);backups=[];O.restoreSelection(doc,made);
      if(!cleaned){throw new Error('Copie di sicurezza nascoste non rimosse: usa Annulla e controlla il documento.');}
      return {message:made.length+' destinazion'+(made.length===1?'e sostituita.':'i sostituite.')};
    }catch(e){
      var recovered=[],ok=true;
      if(!committed){
        for(i=0;i<targets.length;i++){
          if(live(doc,targets[i])){recovered.push(targets[i]);if(backups[i]){try{backups[i].remove();}catch(_){ok=false;}}}
          else if(backups[i]){try{backups[i].hidden=false;recovered.push(backups[i]);}catch(_){ok=false;}}else{ok=false;}
        }
        var keep={},cleanup=[],fresh=O.newRoots(doc,before);for(i=0;i<recovered.length;i++){keep['$'+recovered[i].uuid]=true;}for(i=0;i<fresh.length;i++){if(!keep['$'+fresh[i].uuid]){cleanup.push(fresh[i]);}}if(!O.remove(cleanup)){ok=false;}O.restoreSelection(doc,recovered);
      }
      throw new Error(String(e.message||e)+(committed?'':ok?' Destinazioni conservate o recuperate.':' Ripristino incompleto: usa subito Annulla e controlla il documento.'));
    }finally{try{doc.activeLayer=oldLayer;}catch(_){} }
  };
}(OrdineLab,OrdineCore));

(function(O,C){O.actions.swap=function(doc){var items=O.selection(doc,2,2),bounds=[O.bounds(items[0]),O.bounds(items[1])];O.transform(items,C.swap(bounds),null,bounds);return {message:'Posizioni e dimensioni scambiate. Proporzioni mantenute.'};};}(OrdineLab,OrdineCore));

(function(O,C){O.actions.width=function(doc,cfg){var items=O.selection(doc,cfg.reference==='captured'?1:2),reference=O.referenceItem(doc,items,cfg.reference,'width'),target=C.box(O.bounds(reference)).width,plans=[];for(var i=0;i<items.length;i++){var factor=target/C.box(O.bounds(items[i])).width;if(factor<0.0001||factor>10000){throw new Error('Ridimensionamento troppo estremo.');}plans.push({scale:factor});}O.transform(items,plans);return {message:'Larghezza uniformata. Riferimento: '+O.label(reference,0)+'.'};};}(OrdineLab,OrdineCore));
