#!/bin/bash
set -eu
cd "$(dirname "$0")"
echo "Chiudi Illustrator prima di installare Ordine. Gliffo Suite non viene modificata."
python3 scripts/prepare.py --install
