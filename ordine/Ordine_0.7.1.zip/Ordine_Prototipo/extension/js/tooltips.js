/* Delayed, dismissible, hoverable help. No host calls and no document mutations. */
(function(root){
'use strict';
var popup=document.createElement('div');popup.id='ordine-tooltip';popup.className='tooltip';popup.setAttribute('role','tooltip');popup.hidden=true;document.body.appendChild(popup);
var owner=null,showTimer=null,hideTimer=null;
function hide(){clearTimeout(showTimer);clearTimeout(hideTimer);showTimer=null;hideTimer=null;if(owner){owner.removeAttribute('aria-describedby');}owner=null;popup.hidden=true;}
function deferHide(){if(owner&&document.activeElement===owner){return;}clearTimeout(showTimer);clearTimeout(hideTimer);hideTimer=setTimeout(hide,140);}
function schedule(node,content,delay){
 hide();owner=node;
 showTimer=setTimeout(function(){
  if(owner!==node||!document.documentElement.contains(node)||node.disabled){return;}
  var data=typeof content==='function'?content():content;popup.textContent='';
  var title=document.createElement('strong'),text=document.createElement('p');title.textContent=data.title;text.textContent=data.text||'';popup.appendChild(title);popup.appendChild(text);popup.hidden=false;node.setAttribute('aria-describedby',popup.id);
  var r=node.getBoundingClientRect(),w=popup.offsetWidth,h=popup.offsetHeight;
  var left=Math.max(8,Math.min(innerWidth-w-8,r.left+r.width/2-w/2));
  var top=r.bottom+9;if(top+h>innerHeight-8){top=r.top-h-9;}
  popup.style.left=left+'px';popup.style.top=Math.max(8,Math.min(innerHeight-h-8,top))+'px';
 },delay);
}
popup.addEventListener('mouseenter',function(){clearTimeout(hideTimer);});popup.addEventListener('mouseleave',deferHide);
root.addEventListener('scroll',hide,true);root.addEventListener('resize',hide);document.addEventListener('keydown',function(e){if(e.key==='Escape'){hide();}});
root.OrdineTips={hide:hide,attach:function(node,content){node.addEventListener('mouseenter',function(){schedule(node,content,750);});node.addEventListener('mouseleave',deferHide);node.addEventListener('focus',function(){schedule(node,content,350);});node.addEventListener('blur',hide);node.addEventListener('pointerdown',hide);node.addEventListener('click',hide);}};
}(window));
