/* One native call; no PNG, contour analysis, session or cache. */
(function(root){'use strict';
root.OrdineBalance={run:async function(settings,progress){
 progress('Equilibro gli oggetti in Illustrator…');
 const started=Date.now(),result=await OrdineBridge.call('balanceQuick',settings);
 if(result.operation!=='balanceQuick')throw Error('Risposta non valida per Equilibra loghi.');
 const duration=Date.now()-started;return {ok:true,durationMs:duration,message:result.message+' Tempo: '+(duration/1000).toFixed(2).replace('.',',')+' s.'};
}};
}(window));
