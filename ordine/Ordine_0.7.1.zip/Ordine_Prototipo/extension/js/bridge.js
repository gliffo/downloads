(function(root){'use strict';var running=false;root.OrdineBridge={available:!!root.__adobe_cep__,call:function(action,options){
if(running){return Promise.reject(new Error('Attendi il completamento dell’azione in corso.'));}
if(!root.__adobe_cep__){return Promise.reject(new Error('Anteprima del pannello: apri Ordine in Illustrator per eseguire le azioni.'));}
running=true;return new Promise(function(resolve,reject){
var encoded=encodeURIComponent(JSON.stringify({action:action,options:options||{}})).replace(/'/g,'%27');
try{root.__adobe_cep__.evalScript("OrdineLab.dispatch('"+encoded+"')",function(raw){running=false;try{var response=JSON.parse(raw);if(response.operation&&response.operation!==action){throw new Error('Risposta host per '+response.operation+' ricevuta durante '+action+'. Chiudi Illustrator e reinstalla Ordine aggiornato.');}if(!response.ok){throw new Error(response.message||'Azione non riuscita.');}resolve(response);}catch(e){reject(new Error(raw==='EvalScript error.'?'Host Ordine non caricato: riapri il pannello o verifica l’installazione.':e.message));}});}catch(e){running=false;reject(e);}
});}};}(window));
